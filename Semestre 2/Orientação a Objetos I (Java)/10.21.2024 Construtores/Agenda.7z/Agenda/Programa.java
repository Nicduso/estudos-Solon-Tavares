package journal;

import java.util.ArrayList;
import java.util.List;

public class Programa {

    public static void main(String[] args) {

        Agenda agenda = new Agenda();

        agenda.adicionarContato("João Silva", "12345-6789");
        agenda.adicionarContato("Maria Oliveira", "98765-4321");
        agenda.adicionarContato("Pedro Santos", "11111-2222");

        System.out.println("Contatos iniciais:");
        agenda.exibirContatos();

        System.out.println("\nBuscando por nome 'Maria Oliveira':");
        Contato contatoBuscado = agenda.buscarPorNome("Maria Oliveira");
        System.out.println(contatoBuscado != null ? contatoBuscado : "Contato não encontrado.");

        System.out.println("\nBuscando por telefone '11111-2222':");
        contatoBuscado = agenda.buscarPorTelefone("11111-2222");
        System.out.println(contatoBuscado != null ? contatoBuscado : "Contato não encontrado.");

        System.out.println("\nEditando contato 'João Silva':");
        agenda.editarContato("João Silva", "João Pedro", "55555-4444");
        agenda.exibirContatos();

        System.out.println("\nRemovendo contato 'Maria Oliveira':");
        agenda.removerContato("Maria Oliveira");
        agenda.exibirContatos();
    }
}