package journal;

import java.util.ArrayList;
import java.util.List;

public class Agenda {
    private List<Contato> contatos;

    public Agenda() {
        this.contatos = new ArrayList<>();
    }

    public void adicionarContato(String nome, String telefone) {
        contatos.add(new Contato(nome, telefone));
    }

    public void editarContato(String nomeAntigo, String novoNome, String novoTelefone) {
        Contato contato = buscarPorNome(nomeAntigo);
        if (contato != null) {
            contato.setNome(novoNome);
            contato.setTelefone(novoTelefone);
        } else {
            System.out.println("Contato não encontrado: " + nomeAntigo);
        }
    }

    public void removerContato(String nome) {
        Contato contato = buscarPorNome(nome);
        if (contato != null) {
            contatos.remove(contato);
        } else {
            System.out.println("Contato não encontrado: " + nome);
        }
    }

    public Contato buscarPorNome(String nome) {
        for (Contato contato : contatos) {
            if (contato.getNome().equalsIgnoreCase(nome)) {
                return contato;
            }
        }
        return null;
    }

    public Contato buscarPorTelefone(String telefone) {
        for (Contato contato : contatos) {
            if (contato.getTelefone().equals(telefone)) {
                return contato;
            }
        }
        return null;
    }

    public void exibirContatos() {
        if (contatos.isEmpty()) {
            System.out.println("A agenda está vazia.");
        } else {
            System.out.println("Contatos:");
            for (Contato contato : contatos) {
                System.out.println(contato);
            }
        }
    }

}
