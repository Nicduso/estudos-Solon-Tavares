package person;

import java.util.Scanner;

public class Idade {
    public static void main(String[] args) {
    
        Pessoa pessoa1 = new Pessoa("Luana", "Cabelereira", 25);

        pessoa1.info();
        pessoa1.idadeDias();

    }
}