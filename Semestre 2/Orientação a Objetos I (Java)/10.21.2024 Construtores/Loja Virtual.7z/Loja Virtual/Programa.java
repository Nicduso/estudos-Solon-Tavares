package loja;

import java.util.ArrayList;
import java.util.List;

public class Programa {
    
    public static void main(String[] args) {
        LojaVirtual loja = new LojaVirtual();

        loja.cadastrarProduto("Notebook", 3000.00, 10);
        loja.cadastrarProduto("Mouse", 50.00, 20);
        loja.cadastrarProduto("Teclado", 100.00, 15);

        loja.listarProdutos();

        loja.adicionarAoCarrinho("Notebook", 1);
        loja.adicionarAoCarrinho("Mouse", 2);

        loja.exibirCarrinho();

        loja.aplicarDesconto(10); 

        System.out.printf("Valor total com desconto: R$ %.2f%n", loja.calcularTotal());
    }
}