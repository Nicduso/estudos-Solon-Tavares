package loja;

import java.util.ArrayList;
import java.util.List;

public class LojaVirtual {
    private List<Produto> produtos;
    private List<ItemCarrinho> carrinho;
    private double desconto;

    public LojaVirtual() {
        this.produtos = new ArrayList<>();
        this.carrinho = new ArrayList<>();
        this.desconto = 0.0;
    }

    public void cadastrarProduto(String nome, double preco, int estoque) {
        produtos.add(new Produto(nome, preco, estoque));
    }

    public void adicionarAoCarrinho(String nomeProduto, int quantidade) {
        Produto produto = buscarProduto(nomeProduto);
        if (produto != null) {
            carrinho.add(new ItemCarrinho(produto, quantidade));
            produto.diminuirEstoque(quantidade);
        } else {
            throw new IllegalArgumentException("Produto não encontrado.");
        }
    }

    private Produto buscarProduto(String nomeProduto) {
        for (Produto produto : produtos) {
            if (produto.getNome().equalsIgnoreCase(nomeProduto)) {
                return produto;
            }
        }
        return null;
    }

    public void aplicarDesconto(double percentual) {
        if (percentual < 0 || percentual > 100) {
            throw new IllegalArgumentException("Percentual de desconto inválido.");
        }
        this.desconto = percentual;
    }

    public double calcularTotal() {
        double total = 0.0;
        for (ItemCarrinho item : carrinho) {
            total += item.getTotal();
        }
        return total - (total * (desconto / 100));
    }

    public void listarProdutos() {
        System.out.println("Produtos disponíveis:");
        for (Produto produto : produtos) {
            System.out.printf("%s - R$ %.2f - Estoque: %d%n", produto.getNome(), produto.getPreco(), produto.getEstoque());
        }
    }

    public void exibirCarrinho() {
        System.out.println("Carrinho de compras:");
        for (ItemCarrinho item : carrinho) {
            System.out.printf("%s - Quantidade: %d - Total: R$ %.2f%n", item.getProduto().getNome(), item.getQuantidade(), item.getTotal());
        }
    }

}
