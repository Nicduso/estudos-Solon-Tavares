package hospital;

import java.util.Scanner;

class Paciente {

    Scanner scan = new Scanner (System.in);

    private String nome;
    private int idade;
    private String data, hora;
    private String[] consulta = new String[10];
    public int op = 1;

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setIdade(int idade){
        this.idade = idade;
    }

    public String getNome(){
        return this.nome;
    }

    public int getIdade(){
        return this.idade;
    }

    public void menu(){

            System.out.println ("\nEscolha entre as seguintes opções:\n 1 - Cadastrar nova consulta\n 2 - Consultar todas as consultas\n 3 - Encerrar programa");
            System.out.print ("Opção: ");
            this.op = scan.nextInt();

    }

    public void consulta(){

        int n = 0;
        int i;
        int indice;
        Scanner scan = new Scanner(System.in);

        while (this.op < 3) {
            
            menu();

            if (this.op > 3) {

                System.out.println ("\nOpção inválida");
                this.op = 1;

            } else {

                switch (this.op) {
                    case 1:

                        if (n >= 10) {

                            System.out.println("\nO limite de 10 consultas já foi atingido.\n");
                            n = 10;

                        } else {

                        System.out.print("Data da consulta: ");
                        this.data = scan.next();

                        System.out.print("Hora da consulta: ");
                        this.hora = scan.next();
                        indice = n + 1;
                        this.consulta[n] = ("\nConsulta "+indice+": \n Data: "+data+"\n Hora: "+hora);

                        n++;

                        }

                    break;

                    case 2:
                        
                        System.out.println("\n##### Consultas #####\n");

                        for (i = 0; i < n; i++) {
                            
                            System.out.println(this.consulta[i]+"\n");
                            
                        }

                    break;

                    default:

                        System.out.println ("\nObrigado por consultar. Volte sempre!");

                }

            }

            }

        }

    }